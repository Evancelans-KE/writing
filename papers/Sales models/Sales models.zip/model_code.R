
#LINEAR REGRESSION 

summary(sales)

> plot(sales$id,sales$sales)

#LOGISTIC REGRESSION

