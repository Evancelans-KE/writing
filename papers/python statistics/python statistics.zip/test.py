import pandas as pd 

f = pd.read_csv("C:\Users\2395648\Documents\class\hello\papers\python statistics\dataset.csv")
print(f.head())
