package model;

/**
 * Represents the &lt;a&gt; tag.
 * @author UMCP
 *
 */
public class AnchorElement extends TagElement {
	private String linkText;
	private String url;


}
