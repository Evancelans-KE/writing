<!DOCTYPE html>
<html lang="en">
<head>
    <title>Awesome Blog</title>
</head>
<body>
<?php include "header.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
    <h1>Welcome to Our Website!</h1>
    <p>Here you will find lots of useful information.</p>
<?php include "footer.php"; ?>
</body>
</html>